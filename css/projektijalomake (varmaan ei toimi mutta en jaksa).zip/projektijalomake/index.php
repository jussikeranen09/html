<?php
session_start();
$csrf_token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;
?>

<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">    
    <title>Oma Portfolio</title>
</head>
<body>
<header>
    <h1>Jussi Keränen</h1>
    <h2>Opiskelija</h2>
</header>
<nav>
    <a href="#tietoa">Tietoa</a>
    <a href="#projektit">Projektit</a>
    <a href="#aikataulu">Aikataulu</a>
    <a href="#kartta">Kartta</a>
    <a href="#yhteystiedot">Yhteystiedot</a>
</nav>
<br>
<section id="tietoa">
    <h2>Tietoa minusta</h2>
    <p>Olen Jussi Keränen, opiskelija Savon Ammattiopiston ohjelmointialalla. Olen koko elämäni harrastanut tietokoneiden kanssa, ja halusin nyt oppia ohjelmointia. 
        Tietokoneiden kanssa olen tehnyt monenlaisia asioita, kuten kasaamista, korjaamista, käyttöjärjestelmien vaihtelemista, ja paljon muuta.
        <br>
        <p>Kolme adjektiivia vahvuuksistani ovat rauhallinen, itseoppiva ja sinnikäs.</p>
        
    </p>

</section>
<br>
<section id="projektit">
    <h2>Projektit</h2>
    <a href="https://github.com/jussikeranen09/html" target="_blank">HTML-tehtäviä</a>
    <p>Koulua varten tehtyjä HTML-tehtäviä.</p>
    <br>
    <a href="https://github.com/jussikeranen09/html/tree/main/css" target="_blank">CSS-tehtäviä</a>
    <p>Koulua varten tehtyjä CSS-tehtäviä.</p>
</section>
<br>
<section id="aikataulu">
    <h2>Aikataulu</h2>
    <table border="1">
        <tr>
            <th>Päivä</th>
            <th>Aika</th>
            <th>Tehtävät</th>
        </tr>
        <tr>
            <td>Maanantai</td>
            <td>9:00 - 15:00</td>
            <td>HTML-tehtävät</td>
        </tr>
        <tr>
            <td>Tiistai</td>
            <td>9:00 - 14:00</td>
            <td>HTML-tehtävät</td>
        </tr>
        <tr>
            <td>Keskiviikko</td>
            <td>9:00 - 14:00</td>
            <td>HTML-tehtävät</td>
        </tr>
        <tr>
            <td>Torstai</td>
            <td>9:00 - 14:00</td>
            <td>HTML-tehtävät</td>
        </tr>
        <tr>
            <td>Perjantai</td>
            <td>9:00 - 13:00</td>
            <td>HTML-tehtävät</td>
        </tr>
    </table>
</section>
<br>
<section id="kartta">
    <div style="text-align: center"><iframe width="50%" height="400" frameborder="0" scrolling="no" marginheight="5" marginwidth="50%" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBVizdQeh3udy11xDc5Ao2YStR2gLc-rfc&amp;q=hehkukatu%201&amp;maptype=roadmap&amp;zoom=14"></div></iframe>
</section>
<section id="lomake">
    <h2>Rekisteröitymislomake</h2>

<form action="tarkistus.php" method="POST">
    <label for="nimi">Nimi:</label><br>
    <input type="text" name="nimi" required><br><br>

    <label for="sahkoposti">Sähköposti:</label><br>
    <input type="email" name="sahkoposti" required><br><br>

    <!-- CSRF-token -->
    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

    <input type="submit" value="Lähetä">
</form>

</section>
<footer id="yhteystiedot">
    <h2>Yhteystiedot</h2>
    <p>Sähköposti: <a href="mailto:jussikeranen2009@gmail.com">jussikeranen2009@gmail.com</a></p>
    <p>Github: <a href="https://github.com/jussikeranen09" target="_blank">jussikeranen09</a></p>
</footer>